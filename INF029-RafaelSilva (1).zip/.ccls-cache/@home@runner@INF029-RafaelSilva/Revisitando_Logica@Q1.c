//Faça um programa que imprima o seu nome, sua matrícula, e o seu semestre de ingresso no curso. Cada informação em uma linha.



#include <stdlib.h>
#include <stdio.h>

int main(){
  printf("digite o seu nome o seu nome, sua matrícu" )
}