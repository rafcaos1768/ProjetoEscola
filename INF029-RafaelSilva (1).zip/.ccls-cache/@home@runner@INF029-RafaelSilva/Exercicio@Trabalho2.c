#include <stdlib.h> 
#include <stdio.h> 

void inicializarEstrutura(int **vetor){
    for (int i = 0; i < 10; i++) {
        vetor[i] = NULL;
    }

}

void verificarVetorPrincipal(int posicao, int ** estruturaPrincipal){
    for()
}

void criarEstruturaSecundaria(){
    
}

int main() {
    int posicaoDesejada; 
    int *estruturasSecundarias[5];
    int *estruturaPrincipal[10];
    inicializarEstrutura(estruturaPrincipal);
    

    printf("Em qual posicao da Estrutura voce gostaria de inserir o elemnto ?:");
    scanf("%d", &posicaoDesejada); // lembrar que a posicao eh real 
    verificarVetorPrincipal(posicaoDesejada,&estruturaPrincipal);
    
}