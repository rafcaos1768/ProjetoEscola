/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#define MAX 100

int main()
{   printf( "Hello World!\n")
}








/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#define MAX 100

int main()
{   int i=0;
    int d=0,m=0;
    int ddf =1, mmf=1;
    char string[MAX], mm[3], dd[3],aaa[5];
    scanf("%s", string);
    while(string[i] !='\0'){
        if(string [i]>47 && string[i] <58 && ddf==1){
            dd[d]=string[i];
            d++;

            if(string[i+1]=='/' || d<=2 ){
                ddf=0;
                break;
            }
        }
    //     if(string [i]>48 && string[i] <57 && ddf== 0){
    //         mm[m]=string[i];
    //         m++
    //          if(string[i+1]=='/' && m<2){
    //             mmf=0;
    //         }
    //     }
    //     if(string [i]>48 && string[i] <57 && ddf==0 && mmf==0){
    //         aaaa= string[i];
    //     }

     i++;
     }

     for(int i=0; i<2 ; i++);
         printf("%c", dd[i]);

    return 0;
}

#include <stdio.h>
#define MAX 100

int main()
{   int i=0;
    int d=0,m=0;
    int ddf =1, mmf=1;
    char string[MAX], mm[3], dd[3],aaa[5];
    scanf("%s", string);
    while(string[i] !='\0'){
        if(string [i]>47 && string[i] <58 && ddf==1){
            dd[d]=string[i];
            d++;
            if(string[i]=='/' || d==2 ){
                ddf=0;
                break;
            }
        }
    //     if(string [i]>48 && string[i] <57 && ddf== 0){
    //         mm[m]=string[i];
    //         m++
    //          if(string[i+1]=='/' && m<2){
    //             mmf=0;
    //         }
    //     }
    //     if(string [i]>48 && string[i] <57 && ddf==0 && mmf==0){
    //         aaaa= string[i];
    //     }

     i++;
     }

    //  for(int i=0; i<=2 ; i++);
    //      printf("%c", dd[i]);

    return 0;
}


// while(data[i] !='\0'){
 //   if(data [i]>47 && data[i] <58 || data[i]=='/'){
 //         apenasNumeros=1;
 //   }
 // i++;
 // }
 // if(apenasNumeros==1){

 // }