// nao escrever comentarios com acento, til ou cedilha
// usar verbos para declarar variaveis
// usar o padrao camelCase para declarar variaveis
// cd ProjetoEscola
// comando para executar o projeto gcc escola.c -o escola
// comando para executar o projeto ./escola

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define TAMANHO_DISCENTE 3 // define o tamanho do vetor
typedef struct discente
{ // struct de discente
  int matricula;
  char nome[50]; // ainda estou pensando se essa é a melhor opção de tipo
  char sexo;
  int dataNascimento;
  int cpf; // ainda estou pensando em como fazer o cpf ser valido e se essa é a melhor opção de tipo
  int ativo;
} Discente;

// funcao principal
int main(void)
{                                            
// vetor para adicionar os Discentes
  Discente listaDiscentes[TAMANHO_DISCENTE]; 
// variavel para escolher a opcao do menu
  int opcaoMenu;                             
  int quantidadeDiscentes = 0;
  // variavel para guardar a opcao sair do menu
  int sair = 0; 

// imprime na tela o menu de opcoes
  while (!sair)
  { 
    printf("Projeto escola - Disciplina INF029\n");
    printf("\n<<< Escolha entre as opções abaixo para inciar >>>\n");
    printf("\n0 - Sair\n");
    printf("1 - Discente\n");
    printf("2 - Docente\n");
    printf("3 - Disciplina\n");
// salva a opção escolhida no menu
    scanf("%d", &opcaoMenu); 

    switch (opcaoMenu)
    {
    case 0:
    {
      sair = 1;
      break;
    }
// opcao para cadastrar discente
    case 1:
    { 
// imprime na tela o nome do módulo                                       
      printf("\n<<< Módulo Discente >>>\n"); 
// variavel para sair do módulo
      int sairDiscente = 0;                  
// variavel para escolher a opcao do menu cadastrar alino
      int opcaoDiscente;                    
// imprime na tela o menu de opcoes discente
      while (!sairDiscente)
      {
        printf("\n0 - Voltar\n");
        printf("1 - Cadastrar Discente\n");
        printf("2 - Listar Discente\n");
        printf("3 - Atualizar Discente\n");
        printf("4 - Excluir Discente\n");
        scanf("%d", &opcaoDiscente);

        switch (opcaoDiscente)
        {
        case 0:
        {
          sairDiscente = 1;
          break;
        }
        case 1:
        {
          printf("\n1 - < Cadastrar Discentes >\n");
// verifica se ainda é possível cadastrar mais discentes          
          if (quantidadeDiscentes == TAMANHO_DISCENTE)
          { 
            printf("\nQuantidade maxima de discentes alcancada!\n");
          }
          else
          {
            printf("Digite os dados cadastrais da(o) discente:\n");
            int matricula;
            char nome[50];
            char sexo;
            int dataNascimento;
            int cpf;

            printf("Informe o numero de matricula da(o) discente que deseja cadastrar:\n");
            scanf("%d", &matricula);

// verifica se o numero de matricula eh menor que zero
            if (matricula < 0)
            {
              printf("\nErro: Registro de matricula invalida!\n");
              break;
            }

            if (!matricula)
            {
              printf("\nErro: o campo nome eh obrigatorio!\n");
              break;
            }
            else
            {
// validacao para verificar se o numero de matricula ja existe              
              for (int i = 0; i < quantidadeDiscentes; i++)
              { 
                if (matricula == listaDiscentes[quantidadeDiscentes].matricula)
                {
                  printf("\nErro: Registro de matricula ja cadastrada!\n");
                  break;
                }
              }
            }
// salva o numero de matricula no vetor
            listaDiscentes[quantidadeDiscentes].matricula = matricula; 
// marca como ativo o discente            
            listaDiscentes[quantidadeDiscentes].ativo = 1;             
            quantidadeDiscentes++;
            printf("\nRegistro da(o) matricula do(a) discente cadastrado com sucesso!\n");

            printf("Digite o nome da(o) discente que deseja cadastrar:\n");
            scanf("%c", &nome);
            if(!nome){
            printf("\nErro: o campo nome eh obrigatorio!\n");
              break;
            } else{
              printf("\nNome da(o) discente cadastrado com sucesso!\n");
              listaDiscentes[quantidadeDiscentes].nome = nome;
            }

            printf("Digite o sexo da(o) discente que deseja cadastrar (M) ou (F):\n");
            scanf("%c", &sexo); // não está salvando!!!
            if (!sexo)
            {
              printf("\nErro: o campo sexo eh obrigatorio!\n");
              break;
            }
            else
            {
              listaDiscentes[quantidadeDiscentes].sexo = sexo;
              printf("\nSexo da(o) discente cadastrado com sucesso!\n");
            }

            printf("Digite a data de nascimento da(o) discente que deseja cadastrar:\n");
            scanf("%d", &dataNascimento);
            if (!dataNascimento)
            {
              listaDiscentes[quantidadeDiscentes].dataNascimento = dataNascimento;
              printf("\nErro: o campo data de nascimento eh obrigatorio!\n");
              break;
            }
            else
            {
              listaDiscentes[quantidadeDiscentes].dataNascimento = dataNascimento;
              printf("\nData de nascimento da(o) discente cadastrado com sucesso!\n");
            }

            printf("Digite cpf da(o) discente que deseja cadastrar:\n");
            scanf("%d", &cpf);
            if (!cpf)
            {
              printf("\nErro: o campo cpf eh obrigatorio!\n");
              break;
            }
            else
            {
              listaDiscentes[quantidadeDiscentes].cpf = cpf;
              printf("\nCPF da(o) discente cadastrado com sucesso!\n");
            }
          }
          break;
        }
        case 2:
        {
// listar a quantidade de discentes
          printf("2 - < Listar Discentes >\n\n "); 
          if (quantidadeDiscentes == 0)
          {
            printf("\nErro: Nenhum registro de discente cadastrado!\n");
            break;
          }
          else
          {
            for (int i = 0; i < quantidadeDiscentes; i++)
            {
              if (listaDiscentes[i].ativo == 1)
              {
                printf("Matricula: %d\n", listaDiscentes[i].matricula);
                // printf("Nome: %c\n", listaDiscentes[i].nome);
                printf("Sexo: %c\n", listaDiscentes[i].sexo);
                printf("Data Nascimento: %c\n", listaDiscentes[i].dataNascimento);
                printf("CPF: %c\n", listaDiscentes[i].cpf);
              }
            }
          }
          break;
        }
        case 3:
        {
          printf("3 - < Atualizar Discente >\n");
          printf("Digite o numero matricula da(o) discente que deseja atualizar:\n");

          int matricula;
          scanf("%d", &matricula);

          int discenteEncontrado = 0;

          if (matricula < 0)
          {
            printf("\nErro: Matricula invalida!\n");
          }
          else
          {
            for (int i = 0; i < quantidadeDiscentes; i++)
            {
              if (matricula == listaDiscentes[i].matricula && listaDiscentes[i].ativo)
              {
                discenteEncontrado = 1;
                break;
              }
            }
            if (!discenteEncontrado)
            {
              printf("\nErro: Registro da(o) discente nao encontrado!\n");
              break;
            }
          }
          int sair = 0;
          int opcaoAtualizar;

          char nome;
          char sexo;
          int dataNascimento;
          int cpf;

          while (!sair)
          {
            printf("\n0 - Sair\n");
            printf("1 - Atualizar nome\n");
            printf("2 - Atualizar sexo\n");
            printf("3 - Atualizar data de nascimento\n");
            printf("4 - Atualizar cpf\n");
            scan("%d", &opcaoAtualizar);

            switch (opcaoAtualizar)
            {
            case 0:
            {
              sair = 1;
              break;
            }
            case 1:
            {
              printf("Digite o nome da(o) discente que deseja atualizar:\n");
              scanf("%c", &nome);
              listaDiscentes[quantidadeDiscentes].nome = nome;
              printf("\nNome da(o) discente atualizado com sucesso!\n");
              break;
            }
            case 2:
            {
              printf("Digite o sexo da(o) discente que deseja atualizar:\n");
              scanf("%c", &sexo);
              listaDiscentes[quantidadeDiscentes].sexo = sexo;
              printf("\nSexo da(o) discente atualizado com sucesso!\n");
              break;
            }
            case 3:
            {
              printf("Digite a data de nascimento da(o) discente que deseja atualizar:\n");
              scanf("%d", &dataNascimento);
              listaDiscentes[quantidadeDiscentes].dataNascimento = dataNascimento;
              printf("\nData de nascimento da(o) discente atualizado com sucesso!\n");
              break;
            }
            case 4:
            {
              printf("Digite cpf da(o) discente que deseja atualizar:\n");
              scanf("%d", &cpf);
              listaDiscentes[quantidadeDiscentes].cpf = cpf;
              printf("\nCPF da(o) discente atualizado com sucesso!\n");
              break;
            }
            }
          }
        break;
        }
        case 4:
      {
        printf("4 - < Excluir Discente >\n");
        printf("Digite o numero matricula da(o) discente que deseja excluir:\n");
        int matricula;
        scanf("%d", &matricula);

// essa variável serve para verificar se o discente foi encontrado ou não
        int discenteEncontrado = 0;

// verifica se o numero de matricula eh menor que zero
        if (matricula < 0)
        {
          printf("\nErro: Matricula invalida!\n");
        }
        else
        {
// busca no array o registro do estudante cujos dados sao iguais ao numero de matricula
          for (int i = 0; i < quantidadeDiscentes; i++)
          {
            if (matricula == listaDiscentes[i].matricula && listaDiscentes[i].ativo)
            {
              listaDiscentes[i].ativo = -1;

              for (int j = i; j < quantidadeDiscentes - 1; j++)
              {
                listaDiscentes[j].matricula = listaDiscentes[j + 1].matricula;
                listaDiscentes[j].matricula = listaDiscentes[j+1].nome;
                listaDiscentes[j].matricula = listaDiscentes[j + 1].sexo;
                listaDiscentes[j].matricula = listaDiscentes[j + 1].dataNascimento;
                listaDiscentes[j].matricula = listaDiscentes[j + 1].cpf;
                listaDiscentes[j].matricula = listaDiscentes[j + 1].ativo;
              }
              quantidadeDiscentes--;
              discenteEncontrado = 1;
              break;
            }
          }
// caso não seja encontrado o discente exibe a mensagem de erro
          if (!discenteEncontrado)
          {
            printf("\nErro: Registro da(o) discente nao encontrado!\n");
          }
          else
          {
            printf("\nRegistro da(o) discente excluido com sucesso!\n");
          }
        }
        break;
      }
        default:
        {
          printf("Opção invalida (Discente)");
        }
        }
      } 
    }
// opcao para cadastrar docente
    case 2:
    {
      printf("<<< Módulo Docente >>>");
      break;
    }
// opcao para cadastrar discplina
    case 3:
    {
      printf("<<< Módulo Disciplina >>>");
      break;
    }
    default:
    {
      printf("Opção inválida");
    }
    }
    }
  printf("Programa encerrado");
  return 0;
}