*Projeto Escola*

Discentes: Maria Vitória Santos da Silva, Rafael Pimentel Dunda Silva e Ravena Dafne Costa Carneiro

*Comando para rodar o projeto*
# cd ProjetoEscola
# gcc Main.c aluno.c professor.c disciplinas.c validadores.c -o Main 
# ./Main